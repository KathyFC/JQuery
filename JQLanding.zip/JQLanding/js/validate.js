document.contact.addEventListener('submit', validarFormulario);
 
	//validate Name
	function validateName (name) {
		// body...
		if (name==""||name.length<2) {
			alert("Error: you haven't enter your name, please retry.")
		};
	}

	//validate Email
	function validateMail(mail) {
	    expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	    if ( !expr.test(mail) ){
	        alert("Error: The email: " + mail + " is not correct.");
	    }
	    else if (mail==""){
	    	alert("You didn't enter your mail, please retry.");
	    };

	}

	//validate Phone
	function validatePhone(phone){
		if (phone==""){
	    	alert("You didn't enter your Phone, please retry.");
	    }
	    else if (phone.length!=10){
	    	alert("You are missing a number in your Phone, please retry.");
	    };
	}

	//validate Comments
	function validatetA(tA){
		if (tA==""){
	    	alert("You didn't enter your Comments, please retry.");
	    };
	}

	//validate shelter
	function validateShel(shelter){
		if (shelter==""){
	    	alert("You didn't enter your shelter, please retry.");
	    };
	}

	//validate DOB
	function validateDOB(month,day,year){
		if (month==""||day==""||year=="") {
			alert("Your DOB is incorrect, please retry.");
		};

	}
	
	function validarFormulario(evObject) {
		evObject.preventDefault();//evita el envio del formulario
		alert("We made it!");

		var nom=document.getElementById('name').value; //variable que se manipula, 'xxx' id del HTML
		var mail=document.getElementById('mail').value;
		var phone=document.getElementById('phone').value;

		//DOB
		var month=document.getElementById('month').value;
		var day=document.getElementById('day').value;
		var year=document.getElementById('year').value;

		var shelter=document.getElementById('shelter').value;
		var tA=document.getElementById('tA').value;

		//FunctionCalls
		validateName(nom);
		validateMail(mail);
		validatePhone(phone);
		validateDOB(month,day,year);
		validatetA(tA);

		//method by witch it will be sent
		document.contact.method='Post/Get';
		document.contact.action='salvar.php';
		document.contact.submit();
	}






